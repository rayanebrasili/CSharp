﻿using System;
class Programa
{
    static void Main(string[] args)
    {
        Console.WriteLine("Olá, mundo");
        Console.WriteLine("Tecle enter para fechar ...");
        Console.ReadLine();
    }
}


